#pragma once

#include "NewMenu.h"

namespace UPasta {
	namespace SDK {
		namespace MenuSettings {
			extern int BackgroundOpacity;
			extern bool DrawMenu;
		}
	}
}
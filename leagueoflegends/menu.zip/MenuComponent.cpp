#include "stdafx.h"
#include "MenuComponent.h"

#include "MenuSettings.h"

namespace UPasta {
	namespace SDK {
		float MenuComponent::Width = 180.0f;
		float MenuComponent::Height = 35.0f;
	}
}

#include "Ezreal.h"

#include "Awareness.h"
#include "stdafx.h"
#include "TargetSelector.h"

class EzrealModule : public ChampionModule
{
private:
    std::string name = SP_STRING("Ezreal");

private:
    float gameTime = 0.0f;

    float QCastedTime = 0.0f;
    float WCastedTime = 0.0f;
    float ECastedTime = 0.0f;
    float RCastedTime = 0.0f;

private:
    static bool hasW(Object* pEnemy)
    {
        return pEnemy->GetBuffByName("ezrealwattach");
    }

    [[nodiscard]] bool isTimeToCastQ() const
    {
        return gameTime > QCastedTime + database.EzrealQ.GetCastTime();
    }

    [[nodiscard]] bool isTimeToCastW() const
    {
        return gameTime > WCastedTime + database.EzrealW.GetCastTime();
    }

    [[nodiscard]] bool isTimeToCastE() const
    {
        return gameTime > ECastedTime + 0.25f;
    }

    [[nodiscard]] bool isTimeToCastR() const
    {
        return gameTime > RCastedTime + database.EzrealR.GetCastTime();
    }

    static float qRange()    {
        return EzrealConfig::EzrealSpellsSettings::qRange->Value;
    }

    static float wRange()    {
        return EzrealConfig::EzrealSpellsSettings::wRange->Value;
    }

    static float eRange()    {
        return EzrealConfig::EzrealSpellsSettings::eRange->Value;
    }

    static float rRange()    {
        return EzrealConfig::EzrealSpellsSettings::maxRDistance->Value;
    }

    const std::vector<float> qDmgSkillVector = arrayToVector(std::begin(EzrealDamages::QSpell::dmgSkillArray), std::end(EzrealDamages::QSpell::dmgSkillArray));
    const std::vector<float> wDmgSkillVector = arrayToVector(std::begin(EzrealDamages::WSpell::dmgSkillArray), std::end(EzrealDamages::WSpell::dmgSkillArray));
    const std::vector<float> rDmgSkillVector = arrayToVector(std::begin(EzrealDamages::RSpell::dmgSkillArray), std::end(EzrealDamages::RSpell::dmgSkillArray));

    float Ezreal_dmgQ(Object* pEnemy) const {
        return Damage::CalculateSkillDamage(SpellIndex::Q, pEnemy, qDmgSkillVector, Physical, EzrealDamages::QSpell::additionalPercentageAP, EzrealDamages::QSpell::additionalPercentageAD);
    }

    float Ezreal_dmgW(Object* pEnemy) const {
        const int levelSpell = globals::localPlayer->GetSpellBySlotId(SpellIndex::W)->GetLevel();
        return Damage::CalculateSkillDamage(SpellIndex::Q, pEnemy, wDmgSkillVector, Physical, EzrealDamages::WSpell::additionalPercentageAP[levelSpell], EzrealDamages::QSpell::additionalPercentageAD);
    }

    float Ezreal_dmgR(Object* pEnemy) const {
        return Damage::CalculateSkillDamage(SpellIndex::Q, pEnemy, rDmgSkillVector, Physical, EzrealDamages::RSpell::additionalPercentageAP, EzrealDamages::RSpell::additionalPercentageAD);
    }

public:

    EzrealModule()
    {
        ChampionModuleManager::RegisterModule(name, this);
    }

    void Init() override
    {
        const auto EzrealMenu = Menu::CreateMenu("vezEzreal", "vez.Ezreal");

        const auto combo = EzrealMenu->AddMenu("Combo Settings", "Combo Settings");
        EzrealConfig::EzrealCombo::UseQ = combo->AddCheckBox("Use Q", "Use SpellSlot Q", true);
        EzrealConfig::EzrealCombo::UseW = combo->AddCheckBox("Use W", "Use SpellSlot W", true);
        EzrealConfig::EzrealCombo::UseR = combo->AddCheckBox("Use R", "Use SpellSlot R", true);
        EzrealConfig::EzrealCombo::enemiesInRange = combo->AddSlider("minEnemiesInRange", "Minimum enemies to use R", 2, 1, 5, 1);

        const auto harassMenu = EzrealMenu->AddMenu("Harass Settings", "Harass Settings");
        EzrealConfig::EzrealHarass::UseQ = harassMenu->AddCheckBox("Use Q", "Use SpellSlot Q", true);
        EzrealConfig::EzrealHarass::UseW = harassMenu->AddCheckBox("Use W", "Use SpellSlot W", true);
        EzrealConfig::EzrealHarass::minMana = harassMenu->AddSlider("minHarassMana", "Minimum Mana", 60, 1, 100, 5);

        const auto clearMenu = EzrealMenu->AddMenu("Clear Settings", "Clear Settings");
        const auto laneClearMenu = clearMenu->AddMenu("Laneclear Settings", "Laneclear Settings");
        EzrealConfig::EzrealClear::UseQ = laneClearMenu->AddCheckBox("Use Q", "Use SpellSlot Q", true);
        EzrealConfig::EzrealClear::UseW = laneClearMenu->AddCheckBox("Use W", "Use SpellSlot W on turret", true);
        EzrealConfig::EzrealClear::minMana = laneClearMenu->AddSlider("minClearMana", "Minimum Mana", 60, 1, 100, 5);

        const auto jungleMenu = clearMenu->AddMenu("Jungleclear Settings", "Jungleclear Settings");
        EzrealConfig::EzrealJungle::UseQ = jungleMenu->AddCheckBox("Use Q", "Use SpellSlot Q", true);
        EzrealConfig::EzrealJungle::UseW = jungleMenu->AddCheckBox("Use W", "Use SpellSlot W", true);
        EzrealConfig::EzrealJungle::minMana = jungleMenu->AddSlider("minClearMana", "Minimum Mana", 60, 1, 100, 5);

        const auto lastHitMenu = clearMenu->AddMenu("Lasthit Settings", "Lasthit Settings");
        EzrealConfig::EzrealLastHit::UseQ = lastHitMenu->AddCheckBox("Use Q", "Use SpellSlot Q", true);
        EzrealConfig::EzrealLastHit::minMana = lastHitMenu->AddSlider("minClearMana", "Minimum Mana", 60, 1, 100, 5);

        const auto additionalMenu = EzrealMenu->AddMenu("Additional Settings", "Additional Settings");
        const auto ksMenu = additionalMenu->AddMenu("Killsteal Settings", "Killsteal Settings");
        EzrealConfig::EzrealKillsteal::UseQ = ksMenu->AddCheckBox("Use Q", "Use SpellSlot Q", true);
        EzrealConfig::EzrealKillsteal::UseE = ksMenu->AddCheckBox("Use E", "Use SpellSlot E", true);
        EzrealConfig::EzrealKillsteal::UseR = ksMenu->AddCheckBox("Use R", "Use SpellSlot R", true);

        const auto antiGapMenu = additionalMenu->AddMenu("AntiGapCloser Settings", "AntiGapCloser Settings");
        EzrealConfig::EzrealAntiGapCloser::eMode = antiGapMenu->AddList("eMode", "Dash To", std::vector<std::string>{"Near Mouse", "Extend Enemy Dash Position"}, 0);
        EzrealConfig::EzrealAntiGapCloser::UseE = antiGapMenu->AddCheckBox("Use E", "Use SpellSlot E To Mouse", false);
        const auto antiGapwhitelistMenu = antiGapMenu->AddMenu("Whitelist Settings", "Whitelist");

        const auto antiMeleeMenu = additionalMenu->AddMenu("AntiMelee Settings", "AntiMelee Settings");
        EzrealConfig::EzrealAntiMelee::eMode = antiMeleeMenu->AddList("eMode", "Dash To", std::vector<std::string>{"Near Mouse", "Extend Enemy Dash Position"}, 0);
        EzrealConfig::EzrealAntiMelee::UseE = antiMeleeMenu->AddCheckBox("Use E", "Use SpellSlot E To Mouse", false);
        const auto antiMeleewhitelistMenu = antiMeleeMenu->AddMenu("Whitelist Settings", "Whitelist");
        for (int i = 0; i < globals::heroManager->GetListSize(); i++)
        {
            auto obj = globals::heroManager->GetIndex(i);
            if (obj != nullptr && obj->IsEnemy())
            {
                const auto antiGap_checkbox = antiGapwhitelistMenu->AddCheckBox(obj->GetName().c_str(),
                    obj->GetName().c_str(),
                    true,
                    [obj](const CheckBox* self, bool newValue)
                    {
                        if (self->Value == false && !EzrealConfig::EzrealAntiGapCloser::whitelist.empty())
                        {
                            const auto it = std::ranges::find(EzrealConfig::EzrealAntiGapCloser::whitelist, obj);
                            EzrealConfig::EzrealAntiGapCloser::whitelist.erase(it);
                        }
                        else
                        {
                            EzrealConfig::EzrealAntiGapCloser::whitelist.push_back(obj);
                        }
                    });

                if (antiGap_checkbox->Value == true)
                {
                    EzrealConfig::EzrealAntiGapCloser::whitelist.push_back(obj);
                }

                if (!obj->IsMelee()) continue;
                const auto antiMelee_checkbox = antiMeleewhitelistMenu->AddCheckBox(obj->GetName().c_str(),
                    obj->GetName().c_str(),
                    true,
                    [obj]
                    (const CheckBox* self, bool newValue)
                    {
                        if (self->Value == false && !EzrealConfig::EzrealAntiMelee::whitelist.empty())
                        {
                            const auto it = std::ranges::find(EzrealConfig::EzrealAntiMelee::whitelist, obj);
                            EzrealConfig::EzrealAntiMelee::whitelist.erase(it);
                        }
                        else
                        {
                            EzrealConfig::EzrealAntiMelee::whitelist.push_back(obj);
                        }
                    });

                if (antiMelee_checkbox->Value == true)
                {
                    EzrealConfig::EzrealAntiMelee::whitelist.push_back(obj);
                }
            }
        }

        const auto fleeMenu = additionalMenu->AddMenu("Flee Settings", "Flee Settings");
        EzrealConfig::EzrealFlee::UseE = fleeMenu->AddCheckBox("Use E", "Use SpellSlot E To Mouse", false);

        const auto spellsMenu = additionalMenu->AddMenu("Spells Settings", "Spells Settings");
        EzrealConfig::EzrealSpellsSettings::saveMana = spellsMenu->AddCheckBox("saveManaForCombo", "Save Mana For A Full Combo Rotation", true);

        const auto qSpellMenu = spellsMenu->AddMenu("SpellSlot Q Settings", "SpellSlot Q");
        EzrealConfig::EzrealSpellsSettings::qCastMode = qSpellMenu->AddList("castMode", "Cast Mode", std::vector<std::string>{"Doesn't Matter", "While attacking"}, 0);
        EzrealConfig::EzrealSpellsSettings::qRange = qSpellMenu->AddSlider("maxQRange", "Maximum Range", database.EzrealQ.GetRange(), 100, database.EzrealQ.GetRange(), 50);
        EzrealConfig::EzrealSpellsSettings::DrawQ = qSpellMenu->AddCheckBox("Draw Q", "Draw Range", true);

        const auto wSpellMenu = spellsMenu->AddMenu("SpellSlot W Settings", "SpellSlot W");
        EzrealConfig::EzrealSpellsSettings::wCastMode = wSpellMenu->AddList("castMode", "Cast Mode", std::vector<std::string>{"Doesn't Matter", "While attacking"}, 0);
        EzrealConfig::EzrealSpellsSettings::wRange = wSpellMenu->AddSlider("maxWRange", "Maximum Range", database.EzrealW.GetRange(), 100, database.EzrealW.GetRange(), 50);
        EzrealConfig::EzrealSpellsSettings::DrawW = wSpellMenu->AddCheckBox("Draw W", "Draw Range", true);

        const auto eSpellMenu = spellsMenu->AddMenu("SpellSlot E Settings", "SpellSlot E");
        EzrealConfig::EzrealSpellsSettings::eRange = eSpellMenu->AddSlider("maxERange", "Maximum Range", database.EzrealE.GetRange(), 100, database.EzrealE.GetRange(), 50);
        EzrealConfig::EzrealSpellsSettings::DrawE = eSpellMenu->AddCheckBox("Draw E", "Draw Range", true);

        const auto rSpellMenu = spellsMenu->AddMenu("SpellSlot R Settings", "SpellSlot R");
        EzrealConfig::EzrealSpellsSettings::targetMode = rSpellMenu->AddList("targetMode", "Target Selector Mode", std::vector<std::string>{"Inherit", "Near Mouse", "Near Champion"}, 0);
        EzrealConfig::EzrealSpellsSettings::rTapKey = rSpellMenu->AddKeyBind("rTapKey", "Aim SpellSlot R Key", VK_CONTROL, false, false);
        EzrealConfig::EzrealSpellsSettings::minRDistance = rSpellMenu->AddSlider("minRDistance", "SpellSlot R Minimum Fire Distance", 1000, 100, database.EzrealR.GetRange(), 100);
        EzrealConfig::EzrealSpellsSettings::maxRDistance = rSpellMenu->AddSlider("maxRDistance", "SpellSlot R Maximum Fire Distance", 3000, 100, database.EzrealR.GetRange(), 100);

        EzrealConfig::EzrealSpellsSettings::DrawIfReady = spellsMenu->AddCheckBox("DrawIfReady", "Draw SpellSlots Only If Ready", true);
    }

    static bool Ezreal_HasEnoughComboMana()
    {
        if (globals::localPlayer == nullptr) return false;

        const auto getManaCost = [&](SpellIndex spellIndex) {
            return globals::localPlayer->GetSpellBySlotId(spellIndex)->GetManaCost();
        };

        std::initializer_list<SpellIndex> spells = { Q, W, E, R };
        float totalManaCost = 0;

        for (const auto spell : spells) {
            totalManaCost += getManaCost(spell);
            if (spell == R && globals::localPlayer->GetLevel() < 6) break;
        }

        return globals::localPlayer->GetMana() > totalManaCost;
    }

    static bool Ezreal_HasEnoughMana(float minValue)
    {
        return globals::localPlayer != nullptr &&
            (!EzrealConfig::EzrealSpellsSettings::saveMana->Value || Ezreal_HasEnoughComboMana()) &&
            globals::localPlayer->GetPercentMana() > minValue;
    }

  
    void Ezreal_UseAbility(Object* pEnemy, SpellIndex spellID)
    {
        if (globals::localPlayer == nullptr || pEnemy == nullptr) return;

        auto isCastable = [&]() -> bool {
            switch (spellID) {
				case Q: return database.EzrealQ.IsCastable();
				case W: return database.EzrealW.IsCastable();
				case E: return database.EzrealE.IsCastable();
				case R: return database.EzrealR.IsCastable();
                default: return false;
            }};

        if (!isCastable()) return;

        auto abilityRange = [&]() -> float {
            switch (spellID) {
				case Q: return qRange();
				case W: return wRange();
				case E: return eRange();
				case R: return rRange();
                default: return 0.0f;
            }};

        if (pEnemy->GetDistanceTo(globals::localPlayer) > abilityRange()) return;

        auto isTimeToCast = [&]() -> bool {
            switch (spellID) {
				case Q: return isTimeToCastQ();
				case W: return isTimeToCastW();
				case E: return isTimeToCastE();
				case R: return isTimeToCastR();
				default: return false;
            }};

        if (!isTimeToCast()) return;

        auto handleSpellCast = [&](Skillshot spellData) {
            prediction::PredictionOutput prediction;
            if (GetPrediction(globals::localPlayer, pEnemy, spellData, prediction)) 
                functions::CastSpell(spellID, prediction.position);
            };

        switch (spellID) {
			case Q:
				handleSpellCast(database.EzrealQ);
                QCastedTime = gameTime;

            break;
			case W:
				handleSpellCast(database.EzrealW);
                WCastedTime = gameTime;
            break;
			case E:
				functions::CastSpell(E, functions::GetMouseWorldPos());
				ECastedTime = gameTime;
            break;
			case R:
				handleSpellCast(database.EzrealR);
                RCastedTime = gameTime;

            break;
			default: 
                break;
        }

    }

    void Update() override
    {
        gameTime = functions::GetGameTime();

        Killsteal();
        AntiGapCloser();
        AntiMelee();

        if (EzrealConfig::EzrealSpellsSettings::rTapKey->Value == true && database.EzrealR.IsCastable())
        {
            switch (EzrealConfig::EzrealSpellsSettings::targetMode->Value)
            {
            case 0: //Inherit
                if (const auto rTarget = TargetSelector::Functions::GetEnemyChampionInRange(rRange()))
                    Ezreal_UseAbility(rTarget, R);
                break;
            case 1: //NearMouse
                if (const auto rTarget2 = TargetSelector::Functions::GetEnemyChampionInRange(functions::GetMouseWorldPos(), 300.0f))
                    Ezreal_UseAbility(rTarget2, R);
            	break;
            case 2: //NearChampion
                if (const auto rTarget3 = TargetSelector::Functions::GetEnemyChampionInRange(globals::localPlayer->GetPosition(), 500.0f))
                    Ezreal_UseAbility(rTarget3, R);
                break;
            }
        }
    }

    void Attack() override
    {
        if (EzrealConfig::EzrealCombo::UseR->Value == true && database.EzrealR.IsCastable() && TargetSelector::Functions::GetTargetsInRange(globals::localPlayer->GetPosition(), EzrealConfig::EzrealSpellsSettings::minRDistance->Value).size() >= EzrealConfig::EzrealCombo::enemiesInRange->Value)
        {
            if (const auto rTarget = TargetSelector::Functions::GetEnemyChampionInRange(rRange()))
                Ezreal_UseAbility(rTarget, R);
        }

        if (EzrealConfig::EzrealCombo::UseW->Value == true && database.EzrealW.IsCastable() && EzrealConfig::EzrealSpellsSettings::wCastMode->Value == 0)
        {
            if (const auto wTarget = TargetSelector::Functions::GetEnemyChampionInRange(wRange()))
                Ezreal_UseAbility(wTarget, W);
        }

        if (EzrealConfig::EzrealCombo::UseQ->Value == true && database.EzrealQ.IsCastable() && EzrealConfig::EzrealSpellsSettings::qCastMode->Value == 0)
        {
            if (const auto qTarget = TargetSelector::Functions::GetEnemyChampionInRange(qRange()))
                Ezreal_UseAbility(qTarget, Q);
        }
    }

    void Clear() override
    {
        //Laneclear
        if (TargetSelector::Functions::GetMinionsInRange(globals::localPlayer->GetPosition(), qRange()).size() > 0)
        {
           
            if (!Ezreal_HasEnoughMana(EzrealConfig::EzrealClear::minMana->Value)) return;

            if (EzrealConfig::EzrealClear::UseQ->Value == true && database.EzrealQ.IsCastable())
            {
                const auto qTarget = TargetSelector::Functions::GetEnemyMinionInRange(qRange());
                if (qTarget != nullptr && qTarget->GetHealth() < Ezreal_dmgQ(qTarget))
                    Ezreal_UseAbility(qTarget, Q);
            }
        }

        //Jungleclear
        else if (TargetSelector::Functions::GetJungleMonstersInRange(qRange()).size() > 0)
        {
            if (!Ezreal_HasEnoughMana(EzrealConfig::EzrealJungle::minMana->Value)) return;

            if (EzrealConfig::EzrealJungle::UseW->Value == true && database.EzrealW.IsCastable())
            {
                const auto wTarget = TargetSelector::Functions::GetJungleInRange(wRange());
                if (wTarget != nullptr && (wTarget->GetName().contains("Dragon") || wTarget->GetName().contains("Baron") || wTarget->GetName().contains("Herald")))
                    Ezreal_UseAbility(wTarget, W);
            }

            if (EzrealConfig::EzrealJungle::UseQ->Value == true && database.EzrealQ.IsCastable())
            {
                if (const auto qTarget = TargetSelector::Functions::GetJungleInRange(qRange()))
                    Ezreal_UseAbility(qTarget, Q);
            }
        }
    }


    void Harass() override
    {
        if (!Ezreal_HasEnoughMana(EzrealConfig::EzrealHarass::minMana->Value))
            return;

        if (EzrealConfig::EzrealHarass::UseW->Value == true && database.EzrealW.IsCastable() && EzrealConfig::EzrealSpellsSettings::wCastMode->Value == 0)
        {
            if (const auto wTarget = TargetSelector::Functions::GetEnemyChampionInRange(wRange()))
                Ezreal_UseAbility(wTarget, W);
        }

        if (EzrealConfig::EzrealHarass::UseQ->Value == true && database.EzrealQ.IsCastable() && EzrealConfig::EzrealSpellsSettings::qCastMode->Value == 0)
        {
            if (const auto qTarget = TargetSelector::Functions::GetEnemyChampionInRange(qRange()))
                Ezreal_UseAbility(qTarget, Q);
        }
    }

    void Lasthit() override
    {
        if (!Ezreal_HasEnoughMana(EzrealConfig::EzrealLastHit::minMana->Value))
            return;

        if (EzrealConfig::EzrealLastHit::UseQ->Value == true && database.EzrealQ.IsCastable())
        {
            const auto minion = TargetSelector::Functions::GetMinionInRange(qRange());
            if (minion != nullptr && minion->GetHealth() < Ezreal_dmgQ(minion))
                Ezreal_UseAbility(minion, Q);
        }
    }

    void Flee() override
    {
        if (EzrealConfig::EzrealFlee::UseE->Value == true && database.EzrealE.IsCastable())
        {
            const Vector3 pathEnd = functions::GetMouseWorldPos();
            if (pathEnd.IsValid() && globals::localPlayer->IsInRange(pathEnd, 750.0f) && isTimeToCastE())
            {
                functions::CastSpell(SpellIndex::E, functions::GetMouseWorldPos());
                ECastedTime = gameTime;
            }
        }
    }

    void Killsteal()
    {
        __try {
            if (EzrealConfig::EzrealKillsteal::UseQ->Value == true && database.EzrealQ.IsCastable())
            {
                const auto qTarget = TargetSelector::Functions::GetEnemyChampionInRange(qRange());
                if (qTarget != nullptr && qTarget->GetHealth() < Ezreal_dmgQ(qTarget))
                {
                    Ezreal_UseAbility(qTarget, Q);
                }
            }

            if (EzrealConfig::EzrealKillsteal::UseR->Value == true && database.EzrealR.IsCastable())
            {
                const auto rTarget = TargetSelector::Functions::GetEnemyChampionInRange(rRange());
                if (rTarget != nullptr
                    && rTarget->GetDistanceTo(globals::localPlayer) > EzrealConfig::EzrealSpellsSettings::minRDistance->Value
                    && rTarget->GetDistanceTo(globals::localPlayer) < EzrealConfig::EzrealSpellsSettings::maxRDistance->Value
                    && rTarget->GetHealth() < Ezreal_dmgR(rTarget))
                {
                    Ezreal_UseAbility(rTarget, R);
                }
            }
        }
        __except (1)
        {
            LOG("ERROR IN KILLSTEAL MODE");
        }
    }

    void AntiGapCloser()
    {
        if (EzrealConfig::EzrealAntiGapCloser::UseE->Value == true && functions::GetSpellState(SpellIndex::E) == 0)
        {
            for (auto target : TargetSelector::Functions::GetTargetsInRange(globals::localPlayer->GetPosition(), 750.0f))
            {
                if (!functions::MenuItemContains(EzrealConfig::EzrealAntiGapCloser::whitelist, target->GetName().c_str())) continue;
                if (!target->GetAiManager()->IsDashing()) continue;
                if (target->GetBuffByName("rocketgrab2")) continue;

                if (target != nullptr)
                {
                    const Vector3 pathEnd = target->GetAiManager()->GetPathEnd();
                    if (pathEnd.IsValid() && globals::localPlayer->IsInRange(pathEnd, 750.0f))
                    {
                        Ezreal_UseAbility(target, E);
                    }
                }
            }
        }
    }

    void AntiMelee()
    {
        if (EzrealConfig::EzrealAntiMelee::UseE->Value == true && functions::GetSpellState(SpellIndex::E) == 0)
        {
            for (auto target : TargetSelector::Functions::GetTargetsInRange(globals::localPlayer->GetPosition(), 750.0f))
            {
                if (!functions::MenuItemContains(EzrealConfig::EzrealAntiMelee::whitelist, target->GetName().c_str())) continue;

                if (target != nullptr && target->IsInRange(globals::localPlayer->GetPosition(), target->GetAttackRange()))
                {
                    const Vector3 pathEnd = functions::GetMouseWorldPos();
                    if (pathEnd.IsValid() && globals::localPlayer->IsInRange(pathEnd, 750.0f))
                    {
                        Ezreal_UseAbility(target, E);
                    }
                }
            }
        }
    }

    //Events
    void OnBeforeAttack() override
    {
        __try {
            //Combo mode
            if (globals::scripts::orbwalker::orbwalkState == OrbwalkState::Attack)
            {
                const auto object = functions::GetSelectedObject();
                if (object != nullptr && object->IsHero())
                {
                    if (EzrealConfig::EzrealCombo::UseW->Value == true && database.EzrealW.IsCastable() && EzrealConfig::EzrealSpellsSettings::wCastMode->Value == 1)
                    {
                        Ezreal_UseAbility(object, W);
                    }

                    if (EzrealConfig::EzrealCombo::UseQ->Value == true && database.EzrealQ.IsCastable() && EzrealConfig::EzrealSpellsSettings::qCastMode->Value == 1)
                    {
                        Ezreal_UseAbility(object, Q);
                    }
                }
            }
            //Laneclear mode
            if (globals::scripts::orbwalker::orbwalkState == OrbwalkState::Clear)
            {
                const auto object = functions::GetSelectedObject();
                if (object != nullptr && object->IsBuilding())
                {
                    if (EzrealConfig::EzrealClear::UseW->Value == true && database.EzrealW.IsCastable() && Ezreal_HasEnoughMana(EzrealConfig::EzrealClear::minMana->Value))
                    {
                        Ezreal_UseAbility(object, W);
                    }
                }
            }
            //Harass mode
            if (globals::scripts::orbwalker::orbwalkState == OrbwalkState::Harass)
            {
                const auto object = functions::GetSelectedObject();
                if (object != nullptr && object->IsHero())
                {
                    if (!Ezreal_HasEnoughMana(EzrealConfig::EzrealHarass::minMana->Value))
                        return;

                    if (EzrealConfig::EzrealHarass::UseW->Value == true && database.EzrealW.IsCastable() && EzrealConfig::EzrealSpellsSettings::wCastMode->Value == 1)
                    {
                        Ezreal_UseAbility(object, W);
                    }

                    if (EzrealConfig::EzrealHarass::UseQ->Value == true && database.EzrealQ.IsCastable() && EzrealConfig::EzrealSpellsSettings::qCastMode->Value == 1)
                    {
                        Ezreal_UseAbility(object, Q);
                    }
                }
            }
            
        }
        __except (1)
        {
            LOG("ERROR IN ONBEFOREATTACK MODE");
        }
    }

    void OnCastSpell() override
    {

    }

    void Render() override
    {
        __try {
            if (EzrealConfig::EzrealSpellsSettings::DrawQ->Value == true && (EzrealConfig::EzrealSpellsSettings::DrawIfReady->Value == true && database.EzrealQ.IsCastable() || EzrealConfig::EzrealSpellsSettings::DrawIfReady->Value == false))
                Awareness::Functions::Radius::DrawRadius(globals::localPlayer->GetPosition(), qRange(), COLOR_WHITE, 1.0f);

            if (EzrealConfig::EzrealSpellsSettings::DrawW->Value == true && (EzrealConfig::EzrealSpellsSettings::DrawIfReady->Value == true && database.EzrealW.IsCastable() || EzrealConfig::EzrealSpellsSettings::DrawIfReady->Value == false))
                Awareness::Functions::Radius::DrawRadius(globals::localPlayer->GetPosition(), wRange(), COLOR_WHITE, 1.0f);

            if (EzrealConfig::EzrealSpellsSettings::DrawE->Value == true && (EzrealConfig::EzrealSpellsSettings::DrawIfReady->Value == true && database.EzrealE.IsCastable() || EzrealConfig::EzrealSpellsSettings::DrawIfReady->Value == false))
                Awareness::Functions::Radius::DrawRadius(globals::localPlayer->GetPosition(), eRange(), COLOR_WHITE, 1.0f);
        }
        __except (1)
        {
            LOG("ERROR IN RENDER MODE");
        }
    }
};

EzrealModule module;